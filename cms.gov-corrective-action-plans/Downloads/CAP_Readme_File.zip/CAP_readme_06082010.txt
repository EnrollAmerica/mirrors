Corrective Action Plan (CAP) Data Read-Me File 

****** 

The following files are available for download on the CAP page in the Medicare 
Advantage / Part D Contract and Enrollment Data section on www.cms.hhs.gov:   

CAP Overview (.pdf format)
CAP Read-Me File (.zip format) 
CAP Summary Report (.pdf format) 
CAP Detail Report (.zip format) 
CAP Detail Data File (.zip format) 
CAP Detail Data File � Abbreviated Version (.zip format) 
 

These data are extracted from the CMS Health Plan Management System (HPMS), 
the system of record for MA and Part D contract and plan data.  

****** 

Report/Data File Specifications: 

1 � Include audits where there is a Visit Start Date equal to or greater than 1/1/2006. 

2 � Include MA audits where the Audit Closed Date is null or greater than or equal
to 9/13/2007 (baseline data pull date). 

3 � Include Part D audits where the Entire CAP Released Date is null or greater
than or equal to 9/13/2007 (baseline data pull date).  

4 � Exclude audits where there are no deficient findings. 

5 � Include all deficient elements for a given audit, regardless of the 
current Element Accepted/Released Date status. 

6 � Include all contract numbers associated with an audit, regardless
of contract status.  

7 � Include audits where at least 30 days have elapsed since the Report Issued 
Date (i.e., Report Issued Date + 30 calendar days). 

8 � Exclude the following Part D audit types: a) Program Integrity, b) 1/3
Financial, and c) Other.  

****** 

In total, the reports/files contain the following columns: 

Field Name                       Description/Logic 
----------------------------     ------------------------------------

Organization Name � Displays the �Parent Organization Name� from HPMS. 

Organization Contact � Displays the phone number for the �CAP Report Contact for
Public Website� as entered by the plan organization in HPMS. In the CAP Summary
Report, where there are multiple contract numbers covered by an audit, display the
phone number associated with the first contract number in the list. 

Contract Number(s) � Displays the CMS-assigned contract number(s) covered by the 
audit. 

Contract Name � Displays the legal entity name for the contract number in HPMS. 

Contract Status � Displays the status of the contract in HPMS. 

Contract Status Date � Displays the date associated with the contract status in 
HPMS. 

Plan Type � Displays the contract plan type from HPMS. 

Audit ID � Displays the unique system-generated numeric ID from HPMS. 

Audit Type � Displays the type of audit (i.e., MA, MA-PD, Part D).  

Reason For Corrective Action � Displays the review type through which the 
deficiency is identified (i.e., audit, ad-hoc compliance event). 

Date CAP Requested by CMS � Displays the date on which the CAP was requested by CMS
(Report Issued Date) in HPMS. 

Audit Status � Displays the current status of the audit (i.e., open, closed). Uses 
the Audit Closed Date (MA audits) and the Entire CAP Released Date (Part D audits) 
in HPMS. 

Deficient Areas: Chapters � Displays the audit guide chapter related to the
deficiency. 

Deficient Areas: Elements � Displays the audit guide element related to the
deficiency. 

Element Description � Displays the description of the element from the 
corresponding audit guide. 

Corrective Action Required � Displays the corrective action required as entered by 
CMS in HPMS. 

CAP Status � Displays the current status of the CAP (i.e., open, closed).  Uses the 
CAP Released Date in HPMS. 

****** 

Notes Re: Reports/Data Files: 

CAP Summary Report

1 - This report summarizes the data at the Parent Organization level. 

2 - This report aggregates all unique audit IDs by parent organization and displays 
only one instance of an audit where multiple contract numbers had been included in 
that audit. 

3 -  Where there are multiple audits for the same Parent Organization that have the 
same "Date Corrective Plan Requested by CMS," the report will display one instance. 
(New beginning with February, 2008 CAP Reports.) 

4 - This report displays each unique chapter for which there is a at least 1 �not met� 
finding, across all included contract numbers and visit/audit ID's� in the Deficient Areas: 
Chapters column.  


CAP Detail Report 

1 - This report presents the data at its lowest level of granularity.  Whereas the 
CAP Summary Report is summarized at the audit level, the CAP Detail Report displays 
the information at the audit/contract number/chapter/element level.  In addition, 
this report includes the �Corrective Action Required� for each �not-met� element.  

2 � This report utilizes the same report specifications as noted in the CAP Summary 
Report, except where noted here. 

3 � This report disaggregates the data to the audit/contract number/chapter/element 
level. 

4 � This report displays the contract-specific CAP Report Contact for Public 
Website phone number information instead of the �default� selected for the summary 
report. 

CAP Detail File 

1 � This file presents the data in the CAP Detail Report in a comma separated value 
(.csv) format.  This file is designed for importing into a data processing program, 
such as SAS or Microsoft Access.  

CAP Detail File � Abbreviated 

1 � This file presents the data in the CAP Detail Report (with the exception of the 
�Corrective Action Required� and �Element Description� columns) in a comma separated value
format.  These fields were omitted from the abbreviated file in order to enable importing 
into Excel.  

****** 

