(1) Each program with a .SAS extension has a corresponding .TXT file.  

The .SAS and .TXT files are identical. The .TXT files are provided to make 
the SAS programs easier to view with some text editors. 

File names are case sensitive on some computing platforms, and software 
modules assume that file names are upper case (e.g., AGESEXV6.SAS).

---------------------

(2) The two transport files (each with extension .TRN) contain the format 
library and model coefficients dataset. 

The transport files may be used on any SAS� version 9 platform after 
uploading them and converting them using SAS� PROC CIMPORT. Program 
IMPORT.SAS is provided as an example.

If your computing platform is z/OS, both transport files should be uploaded 
using the following parameters:  RECFM(F or FB) LRECL(80) BLKSIZE(8000).

---------------------

(3) Contents:

Program components (SAS code):

1.	AGESEXV6.SAS
2.	I0V04ED3.SAS
3.	SCOREV4.SAS
4.	V04127H1.SAS
5.	V04127L1.SAS
6.	V0417F3M.SAS
7.	V0417F3P.SAS � main program

Text versions of program components (ASCII text):

8.	AGESEXV6.TXT
9.	I0V04ED3.TXT
10.	SCOREV4.TXT
11.	V04127H1.TXT
12.	V04127L1.TXT
13.	V0417F3M.TXT
14.	V0417F3P.TXT

Calibration coefficients (SAS transport file):

15.	C0413M2.TRN

Diagnosis-to-CC crosswalks (SAS transport file containing SAS formats):

16.	H0417F3.TRN

Text versions of diagnosis-to-CC crosswalks:

17.	H0417F3.FY 2016 ICD10.TXT
18.	H0417F3.FY 2017 ICD10.TXT
19.	H0417F3_ICD10_MCE_age.TXT
20.	H0417F3_ICD10_MCE_sex.TXT

Sample program to read SAS transport files (SAS and text versions):

21.	IMPORT.SAS
22.	IMPORT.TXT

Documentation:

23.	Word file for this release
24.	Excel file for this release
